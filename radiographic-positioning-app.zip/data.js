const procedures = [
{category:"Chest",name:"Chest PA"},
{category:"Chest",name:"Chest Lateral"},
{category:"Abdomen",name:"Abdomen AP Supine"},
{category:"Skull",name:"Skull PA Caldwell"},
{category:"Cervical Spine",name:"Open Mouth"},
{category:"Upper Limb",name:"Hand PA"},
{category:"Lower Limb",name:"Knee AP"}
];
